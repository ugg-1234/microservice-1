package com.microservice.cakecomment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CakecommentApplication {

	public static void main(String[] args) {
		SpringApplication.run(CakecommentApplication.class, args);
	}

}
