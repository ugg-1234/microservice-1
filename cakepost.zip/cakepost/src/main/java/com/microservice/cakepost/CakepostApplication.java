package com.microservice.cakepost;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CakepostApplication {

	public static void main(String[] args) {
		SpringApplication.run(CakepostApplication.class, args);
	}

}
