package com.microservice.cakecomment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CakecommentApplicationTests {

	@Test
	void contextLoads() {
	}

}
